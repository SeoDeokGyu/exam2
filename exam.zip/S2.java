package exam;
/**
 * 
 */

/**
 * @author user
 * [실습]
 * 2. a변수가 19이상이면 성인 아니면 미성년자라고 화면에 표시
 * 단, a변수에는 19가 있다
 * 결과 : 성인
 *
 */
public class S2 {
	public static void main(String[] args) {
		int a = 19;
		if (a>= 19) {
			System.out.println("성인");
		}else {
			System.out.println("미성년자");
		}
	}
}

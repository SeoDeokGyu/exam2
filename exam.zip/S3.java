/**
 * 
 */
package exam;

import java.util.*;


/**
 * @author user
 * 3. 첫줄에 숫자의 총개수 N이 입력
 * 2줄에 N개의 숫자가 랜덤하게 입력
 * 오름차순 정렬해서 화면에 표시하는 코드를 작성
 */
	public class S3 {
		public static void main(String[] args) {
			Scanner scanner = new Scanner(System.in);

			
			int n = scanner.nextInt();

			
			int[] a = new int[n];
			for (int i = 0; i < n; i++) {
				a[i] = i + 1;
			}


			List<Integer> list = new ArrayList<>();
			for (int num : a) {
				list.add(num);
			}
			Collections.shuffle(list);


			for (int i = 0; i < n; i++) {
	            System.out.print(list.get(i) + " ");
	        }
	        System.out.println();


			Arrays.sort(a);



			for (int num : a) {
				System.out.print(num + " ");
			}
		}
	}
